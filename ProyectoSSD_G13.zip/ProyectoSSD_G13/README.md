# iw-bicibletas-compartidas

Sistema de bicicletas compartidas **SI-16**: mapa de disponibilidad en tiempo
real, alquiler y devolución con tarificación, historial de viajes, averías y
taller, balanceo de flota y analítica para el gestor municipal.

- **Backend**: Go (gin + pgx) — API REST en `http://localhost:8080/api/v1`
- **Frontend**: SolidJS + TypeScript + Vite + Tailwind CSS (Leaflet para el mapa, Chart.js para la analítica) — `http://localhost:5173`
- **Datos**: PostgreSQL 16 (persistencia) + Redis 7 (estado en vivo de las estaciones)

## Requisitos

- Docker Desktop (con `docker compose` v2)
- Go ≥ 1.26
- Node.js ≥ 20 (npm ≥ 10)
- Puertos libres: 5432 (PostgreSQL), 6379 (Redis), 8080 (backend), 5173 (frontend)

## Arranque en local

```powershell
# 1) Configuración e infraestructura (raíz del repo)
copy .env.example .env        # revisar JWT_SECRET y TARIFA_MINUTO
docker compose up -d          # postgres + redis; esperar a que estén "healthy"

# 2) Esquema y datos de prueba
cd backend
go run ./cmd/migrate up       # aplica las migraciones de backend/migrations
go run ./cmd/seed             # 60 estaciones, flota, anclajes, usuarios y viajes demo

# 3) Backend — en una terminal
go run ./cmd/server

# 4) Frontend — en otra terminal
cd ../frontend
npm install
npm run dev
```

El seed se puede repetir: deja la base de datos en su estado inicial.
`go run ./cmd/migrate down` revierte la última migración.

Si el puerto 5432 ya está ocupado, crea un `docker-compose.override.yml`
(ignorado por git) con otro puerto y ajusta `DATABASE_URL` en `.env`.

## Usuarios de prueba

Todos con contraseña `password`:

| Email | Rol | Para probar |
|---|---|---|
| `ana@si16.test` | usuario | Abono vigente, viaje activo e historial (HU-02, HU-03, HU-04) |
| `bruno@si16.test` | usuario | Abono caducado: el desbloqueo se rechaza (HU-02) |
| `carla@si16.test` | usuario | Sin abono; dueña de los viajes demo de analítica (HU-08) |
| `diego@si16.test` | usuario | Abono caducado (activo con fecha pasada) |
| `taller@si16.test` | operario_taller | Panel de incidencias y taller (HU-05, HU-06) |
| `logistica@si16.test` | operario_logistica | Alertas de balanceo y traslados (HU-07) |
| `gestor@si16.test` | gestor | Analítica y exportación CSV (HU-08) |

## Tests

```powershell
cd backend
go test -p 1 ./...            # unitarios, contrato e integración

cd ../frontend
npm test                      # Vitest + Testing Library + MSW
npm run lint
```

Los tests de integración necesitan el `docker compose` levantado. Usan su
propia base de datos (`TEST_DATABASE_URL`, se crea sola) y la base lógica 15
de Redis, así que **no tocan los datos de desarrollo**. El comando para pasar
solo el gate de reglas críticas T1–T5 está en
[specs/spec-001/quickstart.md](specs/spec-001/quickstart.md#2-pruebas-automatizadas-gate-de-calidad-de-la-constitución).

## Especificaciones

Cada historia de usuario tiene su spec (Spec Kit) en `specs/`, con
`spec.md`, `plan.md`, `tasks.md`, contratos y quickstart:

| Spec | Historia | Responsable |
|---|---|---|
| [spec-001](specs/spec-001/) | HU-01 — Disponibilidad de estaciones en tiempo real | Iker Roig |
| [spec-002](specs/spec-002/) | HU-02 — Desbloqueo por código de anclaje | Iker Roig |
| [spec-003](specs/spec-003/) | HU-03 — Devolución y tarificación | Alex Morell |
| [spec-004](specs/spec-004/) | HU-04 — Historial de viajes y desglose mensual | Alex Morell |
| [spec-005](specs/spec-005/) | HU-05 — Notificación de averías e inhabilitación | Josep Peiró |
| [spec-006](specs/spec-006/) | HU-06 — Intervenciones técnicas y taller | Josep Peiró |
| [spec-007](specs/spec-007/) | HU-07 — Alertas de balanceo de flota | Alberto Copa |
| [spec-008](specs/spec-008/) | HU-08 — Analítica de uso y exportación CSV | Alberto Copa |

- Plan global, modelo de datos y contrato OpenAPI compartido: [specs/spec-001/](specs/spec-001/)
- Guía de validación de punta a punta (escenarios S1–S8): [specs/spec-001/quickstart.md](specs/spec-001/quickstart.md)
- Historias de usuario originales: [historia.md](historia.md)
